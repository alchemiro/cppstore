#pragma once
#include "Trip.h"
#include <iostream>;
using namespace std;


class TripManagement
{
private:
	Trip** trips;
	int nextFreeIndex;

public:
	TripManagement();
	TripManagement(TripManagement& other);
	TripManagement& operator=(TripManagement& other);
	void operator += (Trip* trip);
	void operator -= (Trip* trip);
	void operator << (TripManagement* mgTrips);
};

