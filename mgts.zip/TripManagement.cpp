#include "TripManagement.h"
#include <iostream>;
using namespace std;

TripManagement::TripManagement() {
	trips = new Trip * [0];
	nextFreeIndex = 0;
}

TripManagement::TripManagement(TripManagement &other) {
	nextFreeIndex = other.nextFreeIndex;
	other.trips = trips;
}

TripManagement& TripManagement::operator=(TripManagement& other) {
	TripManagement(other);
	return *this;
}

void TripManagement::operator+= (Trip* trip) {

	Trip** newTrips = new Trip * [sizeof(trips) + 1];
	if (nextFreeIndex != 0) {
		for (int i = 0; i < sizeof(trips); i++) {
			if (trips[i] != nullptr) {
			newTrips[i] = trips[i];

			}
		}
	}
	newTrips[nextFreeIndex] = trip;

	for (int i = 0; i < sizeof(trips); i++) {
		if (trips[i] == nullptr) {
			nextFreeIndex = i;
			break;
		}
	}
	delete[] trips;
	trips = newTrips;
}

void TripManagement::operator-=(Trip* trip) {
	if (sizeof(trips) == 0) {
		cout << "No trips!";
		return;
	}
	bool firstIndex = true;
	for (int i = 0; i < sizeof(trips); i++) {
		Date pDate = trips[i]->getDate(), tDate = trip->getDate();
		if (pDate == tDate) {
			trips[i] = nullptr;
			if (firstIndex) {
				nextFreeIndex = i;
				firstIndex = false;
			}
		}
	}
}

void TripManagement::operator<<(TripManagement* mgTrips) {
	for (int i = 0; i < sizeof(trips);i++) {
		if (trips[i] != nullptr) {
			cout << trips[i];
		}
	}
}

