#include "TripManagement.h"
#include "Trip.h"
void deleteTrips(TripManagement* mgts);
void AddTrip(TripManagement* mgts);

void main() {
	TripManagement mgts;
	int option;
	do {
		TripManagement* mgtsPtr = &mgts;
		cout << "Please select an option:\n1. Print Trips\n2. Delete Trips\n3. Add Trips\n4. Exit";
		cin >> option;
		switch (option) {
		case 1:
			cout << mgtsPtr << endl;
			break;
		case 2:
			DeleteTrips(mgtsPtr);
			break;
		case 3:
			AddTrip(mgtsPtr);
			break;
		case 4:
			cout << "Bye bye!";
			break;
		default:
			cout << "Invalid option!";
			break;

		}

	} while (option!=4);
}

void DeleteTrips(TripManagement* mgts) {
	int rDay, rMonth, rYear;
	cout << "\nPlease enter the day of the date of the trips you'd like to remove.\n";
	cin >> rDay;
	cout << "\nPlease enter the month of the date of the trips you'd like to remove.\n";
	cin >> rMonth;
	cout << "\nPlease enter the year of the date of the trips you'd like to remove.\n";
	cin >> rYear;

	Date toDel = Date(rDay, rMonth, rYear);

	Trip t("doesntmatter", toDel);
	Trip* tPtr = &t;

	mgts -= tPtr;
}

void AddTrip(TripManagement* mgts) {

	string rDst;
	int rDay, rMonth, rYear;
	cout << "\nPlease enter the destination of the trip.\n";
	cin >> rDst;
	cout << "\nPlease enter the day of the date of the trip.\n";
	cin >> rDay;
	cout << "\nPlease enter the month of the date of the trip.\n";
	cin >> rMonth;
	cout << "\nPlease enter the year of the date of the trip.\n";
	cin >> rYear;

	Date rDate = Date(rDay, rMonth, rYear);
	Trip t(rDst, rDate);
	Trip* tPtr = &t;
	mgts += tPtr;
}