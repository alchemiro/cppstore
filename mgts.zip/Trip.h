#pragma once
#include <string>
#include "Date.h"
using namespace std;

class Trip
{
private:
	static int counter;
	int number;
	string destination;
	Date date;
public:
	Trip(string newDst = "Unknown", Date newDate = Date());
	Trip(Trip &tTrip);
	Trip& operator = (Trip& tTrip);
	~Trip();

	void setDestination(string newDst);
	void setDate(Date newDate);

	int getNumber();
	string getDestination();
	Date getDate();

	void printTrip();
};

