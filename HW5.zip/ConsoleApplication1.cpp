// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include "BirthdayCake.h"
#include "MousseCake.h"
#include "Cake.h"
using namespace std;


int main()
{

    cout << "Hello World!\n";

    
}

