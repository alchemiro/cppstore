#pragma once
#include <ostream>
#include "Trip.h"

class TripManager
{
private:
	Trip** trips;
	int nextFreeIndex;
public:
	TripManager();
	TripManager(const TripManager& other);

	//operators
	TripManager& operator=(const TripManager& other);
	void operator+=(Trip& trip);
	void operator-=(Trip& trip);
	friend ostream& operator<<(ostream& os, const TripManager& t);
};

