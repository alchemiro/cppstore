#include "Trip.h"
#include <string>
#include <iostream>
using namespace std;

Trip** Trip::trips = new Trip*[0];
int Trip::counter = 0;
//constructor
Trip::Trip(string destination, Date tDate) {
	
	if (validate(destination)) {
		dst = destination;
	}
	else {
		dst = "Invalid";
	}

	date = tDate;
	code = ++counter;
}

Trip::Trip(const Trip& other) {
	*this = other;
	this->code = ++counter;
}

Trip::~Trip() {
}

//get
int Trip::getCode(){
	return this->code;
}

string Trip::getDst() {
	return this->dst;
}

Date Trip::getDate() {
	return this->date;
}

//set
void Trip::setDst(string nDst) {
	if (validate(nDst)) {
		this->dst = nDst;
	}
	else {
		this->dst = "Invalid";
	}
}
void Trip::setDate(Date nDate) {
	this->date = nDate;
}
//validate

bool Trip::validate(string destination) {
	for (int i = 0; destination[i] != '\0'; i++) {
		if (isdigit(destination[i])) {
			return false;
		}
	}
	return true;
}
//operator
const Trip& Trip::operator=(const Trip& other) {
	if (this != &other) {
		code = counter;
		counter++;
		dst = other.dst;
		date = other.date;
	}
	return *this;
}

ostream& operator<<(ostream& os, const Trip& t) {
	os << "Trip info:\n" << "Code: " << t.code << "\nDestination: " << t.dst << "\nDate: " << t.date << endl;
	return os;
}