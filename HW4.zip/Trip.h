#include <string>
#include "Date.h"
#include <iostream>
#pragma once
using namespace std;

class Trip
{

private:
	int code;
	string dst;
	Date date;
public:
	static int counter;
	static Trip** trips;
	//constructor
	Trip(string tDst = "Unknown", Date tDate = Date());
	Trip(const Trip& other);
	~Trip();
	//get
	int getCode();
	string getDst();
	Date getDate();
	//set
	void setDst(string newDst);
	void setDate(Date newDate);
	//validate
	bool validate(string tDst);
	//operator
	const Trip& operator=(const Trip& oTrip); 
	//print

	friend ostream& operator<<(ostream& os, const Trip& t);
};

