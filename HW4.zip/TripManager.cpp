#include "TripManager.h"

TripManager::TripManager()
{
	trips = new Trip * [0];
	nextFreeIndex = 0;
}

TripManager::TripManager(const TripManager& other)
{
	*this = other;
}

TripManager& TripManager::operator=(const TripManager& other)
{
	int counttrips=0;
	if (this != &other) {
		while(other.trips[counttrips++] != NULL){}
		this->trips = new Trip * [counttrips];
		for (int i = 0; i < counttrips; i++) {
			this->trips[i] = other.trips[i];
		}
		this->nextFreeIndex = other.nextFreeIndex;
	}
	return *this;
}

void TripManager::operator+=(Trip& trip)
{
	int counter = 0;
	while (this->trips[counter++] != NULL) {}
	Trip** newTrips = new Trip * [counter];
	int secondNull=-1;
	bool foundNull = false;
	for (int i = 0; i < counter; i++) {
		if (this->trips[i] != nullptr) {
			newTrips[i] = trips[i];
		}
		else {
			foundNull = true;
			newTrips[i] = &trip;
		}
		if (foundNull && this->trips[i] == nullptr) {
			secondNull = i;
		}

	}
	if (secondNull != -1) {
		nextFreeIndex = secondNull;
	}
	else {
		nextFreeIndex = counter;
	}
}

void TripManager::operator-=(Trip& trip)
{
	for (int i = 0; this->trips[i] != NULL; i++) {
		if (this->trips[i] != nullptr) {
			if (trip.getDate() == this->trips[i]->getDate()) {
				this->trips[i] = nullptr;
			}
		}
	}
}

ostream& operator<<(ostream& os, const TripManager& t)
{
	for (int i = 0; t.trips[i] != NULL; i++) {
		os << *t.trips[i] << endl;
	}
	return os;
}
