#include <iostream>
#include "Date.h"
#include "Trip.h"
#include "TripManager.h"
using namespace std;

int main() {
	Date d = Date(10, 12, 2004);
	string str;
	cout << "Please enter a destination for the trip." << endl;
	cin >> str;
	Trip t1 = Trip(str, d);
	//cout << t1.counter;
	Trip t2 = Trip(str, d);
	//cout << t2.counter;
	Trip t3 = Trip(str, d);
	//cout << t3.counter;

	TripManager tm = TripManager();
	tm += t1;
	tm += t2;
	tm += t3;
	cout << tm;
	
	return 0;
}